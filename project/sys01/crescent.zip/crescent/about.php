<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="クレセントシューズは靴の素材と履き心地にこだわる方に満足をお届けする東京の靴屋です。後悔しない靴選びはぜひクレセントシューズにお任せください。">
  <meta name="keyword" content="Crescent,shoes,クレセントシューズ,東京,新宿区,メンズシューズ,レディースシューズ,キッズシューズ,ベビーシューズ">

  <title>About | Crescent Shoes</title>
  <link rel="shortcut icon" href="images/favicon.ico">
  <link rel="stylesheet" href="css/styles.css">
  <!-- Font Awesome CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
      <!--[if lt IE 9]>
    <script src="http://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv-printshiv.min.js"></script>
    <script src="http://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
    <!--[if lt IE 8]>
    <![endif]-->
  </head>
  <body class="pageTop" id="pageTop">
    <header class="navbar navbar-default navbar-fixed-top" role="banner">
      <div class="container">
        <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navigation">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <h1 class="navbar-header">
          <a href="index.html" class="navbar-brand"><img src="images/logo01.png" alt="LOGO"></a>
        </h1><!-- /.navbar-header -->
        <nav class="navbar-collapse collapse" id="navigation" role="navigation">
          <ul class="nav navbar-nav">
            <li><a href="index.html">ホーム<span>HOME</span></a></li>
            <li><a href="about.html">会社概要<span>ABOUT</span></a></li>
            <li><a href="news.html">ニュース<span>NEWS</span></a></li>
            <li><a href="shop.html">ショップ<span>ONLINE SHOP</span></a></li>
            <li><a href="contact.html">お問い合わせ<span>CONTACT</span></a></li>
          </ul>
                    <form class="navbar-form" role="search">
            <div class="input-group">
              <input type="text" class="form-control" placeholder="keyword">
              <span class="input-group-btn"><button class="btn btn-default" type="button"><span class="glyphicon glyphicon-search"></span></button></span>
            </div><!-- /.input-group -->
          </form>
        </nav>
      </div>
    </header>
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <nav>
            <h1 class="page-header">About</h1>
            <ol class="breadcrumb">
              <li><a href="index.html">Home</a></li>
              <li class="active">About</li>
            </ol>
          </nav>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <h3>コンセプト</h3>
          <p>どんな靴をお探しですか？<br>ひとそれぞれ好みや条件に違いがあるのでぴったりくる靴を探すのは大変です。<br>デザインはいいけどサイズが合わない、サイズはいいけど素材が気に入らない…<br>仕方なく買った靴はやはりしっくりこないかもしれません</p><p>クレセントシューズでは1足１足時間をかけて厳選したデザイン性とクオリティの高いオリジナル商品や手入れをしながら長くご愛用いただける商品を扱っております。<br>履くたびに足になじむ履き心地のよい靴を心をこめてお送りいたします。</p>
        </div>
        <div class="col-md-6">
          <h3>取り扱いブランド</h3>
          <ul class="list-group">
            <li class="list-group-item"><span class="badge">35</span><i class="fa fa-cube"></i> OVRPHIC</li>
            <li class="list-group-item"><span class="badge">28</span><i class="fa fa-cube"></i> Maison Nargiela</li>
            <li class="list-group-item"><span class="badge">24</span><i class="fa fa-cube"></i> DRIES VEN NOTAN</li>
            <li class="list-group-item"><span class="badge">20</span><i class="fa fa-cube"></i> AmP</li>
            <li class="list-group-item"><span class="badge">18</span><i class="fa fa-cube"></i> Quielp</li>
          </ul>
        </div>
      </div>
      <hr class="page-divider"/>
      <div class="row">
        <div class="col-md-6">
          <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
            <!-- Indicators -->
            <ol class="carousel-indicators">
              <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
              <li data-target="#carousel-example-generic" data-slide-to="1"></li>
              <li data-target="#carousel-example-generic" data-slide-to="2"></li>
              <li data-target="#carousel-example-generic" data-slide-to="3"></li>
            </ol>

            <!-- Wrapper for slides -->
            <div class="carousel-inner" role="listbox">
              <div class="item active">
                <img src="images/about01.jpg" height="550" width="750" alt="...">
              </div>
              <div class="item">
                <img src="images/about02.jpg" height="550" width="750" alt="...">
              </div>
              <div class="item">
                <img src="images/about03.jpg" height="550" width="750" alt="...">
              </div>
              <div class="item">
                <img src="images/about04.jpg" height="550" width="750" alt="...">
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <h3>Company Profile</h3>
          <table class="table table-striped">
            <tr>
              <th>名称</th>
              <td>株式会社 Crescent Shoes（クレセントシューズ）</td>
            </tr>
            <tr>
              <th>所在地</th>
              <td>
                <p>&#12306;169-0073<br />
                  東京都新宿区百人町2-4-8　グレースビル1階<br />
                  TEL/03-1234-5678　<span>FAX/03-1234-5679</span></p>
                </td>
              </tr>
              <tr>
                <th>代表者名</th>
                <td>
                 山田　太郎
               </td>
             </tr>
             <tr>
              <th>事業内容</th>
              <td>シューズ・サンダルの卸と小売</td>
            </tr>
            <tr>
              <th>設立</th>
              <td>2010年11月20日</td>
            </tr>
            <tr>
              <th>資本金</th>
              <td>600万円</td>
            </tr>
            <tr>
              <th>取引銀行</th>
              <td>三井住友銀行</td>
            </tr>
            <tr>
              <th>従業員数</th>
              <td>従業員数　11人（役員　3人  正社員　8人） </td>
            </tr>
          </table>
        </div>
      </div>
    </div>
    <div class="pagetop margin-top-md">
      <a href="#pageTop" class="center-block text-center" onclick="$('html,body').animate({scrollTop: 0}); return false;"><i class="fa fa-chevron-up center-block "></i>Page Top</a>
    </div>
    <footer class="margin-top-md" role="contentinfo">
      <div class="container">
        <div class="row">
          <div class="text-center">
            <ul class="list-inline">
              <li><a href="index.html">HOME</a></li>
              <li><a href="about.html">ABOUT</a></li>
              <li><a href="news.html">NEWS</a></li>
              <li><a href="shop.html">ONLINE SHOP</a></li>
              <li><a href="contact.html">CONTACT</a></li>
            </ul>
            <small>&copy; Crescent Shoes.All Rights Reserved.</small>
          </div><!-- /.text-center -->
        </div><!-- /.row -->
      </div><!-- /.container -->
    </footer>
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
  </html>
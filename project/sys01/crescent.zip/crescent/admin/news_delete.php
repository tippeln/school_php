<?php
require_once "util.inc.php";
require_once "db.inc.php";

$id = $_GET["id"];
// var_dump($id);
// $id = 5;

if ($id == "") {
    $idError = "お知らせが指定されていません";
    header("Location: index.php");
}

$pdo = db_init();
try {
   $stmt = $pdo->prepare("SELECT * FROM news
   WHERE id = (?)");
   $stmt->execute(array($id));
   $itemList = $stmt->fetchAll(PDO::FETCH_ASSOC);
   // header("Location: news_add_done.php");
   }
   catch (PDOException $e) {
   echo $e->getMessage();
   exit;
  }
var_dump($itemList);

if ($_SERVER["REQUEST_METHOD"] === "POST") {

var_dump($_POST);

if ($_POST["delete"] == "削除") {
try {
   $stmt = $pdo->prepare("DELETE FROM news
   WHERE id = (?)");
   $stmt->execute(array($id));
   // $itemList = $stmt->fetchAll(PDO::FETCH_ASSOC);
   header("Location: news_delete_done.php");
   }
   catch (PDOException $e) {
   echo $e->getMessage();
   exit;
  }
} else {
 header("Location: index.php");
}
}
?>

<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title>お知らせの削除 | Crescent Shoes 管理</title>
<link rel="stylesheet" href="css/admin.css">
</head>
<body>
<header>
  <div class="inner">
    <span><a href="index.php">Crescent Shoes 管理</a></span>
    <div id="account">
      admin
      [ <a href="logout.php">ログアウト</a> ]
    </div>
  </div>
</header>
<div id="container">
  <main>
    <h1>お知らせの削除</h1>
    <p>以下のお知らせを削除します。</p>
    <p>よろしければ「削除」ボタンを押してください。</p>
    <form action="" method="post">
    <?php foreach($itemList as $item): ?>
    <table>
      <tr>
        <th class="fixed">日付</th>
        <td>
          <?php echo h($item["posted"]); ?>
        </td>
      </tr>
      <tr>
        <th class="fixed">タイトル</th>
        <td>
        <?php echo h($item["title"]); ?>
        </td>
      </tr>
      <tr>
        <th class="fixed">お知らせ内容</th>
        <td>
        <?php echo h($item["message"]); ?>
        </td>
      </tr>
      <tr>
        <th class="fixed">画像</th>
        <td><img src="../images/press/<?php echo h($item["image"]); ?>" width="64" height="64" alt=""></td>
      </tr>
    </table>
  <?php endforeach; ?>
    <p>
      <input type="submit" name="delete" value="削除">
      <input type="submit" name="cancel" value="キャンセル">
    </p>
    </form>
  </main>
  <footer>
    <p>&copy; Crescent Shoes All rights reserved.</p>
  </footer>
</div>
</body>
</html>
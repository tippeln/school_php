<?php
function getWareki($a)
{
	if(!is_numeric($a)){//空白か文字
		$wareki = "未対応";
	}
	elseif($a < 1868){//0～1867
		$wareki = "未対応";
	}
	else{//1868～

		if($a <= 1911){//1868～1911

			if($a == 1868){
				$wareki = "明治元年";
			}else{
				$year = $a - 1867;
				$wareki = "明治".$year."年";
			}

		}elseif($a <= 1925){//1912～1925)

			if($a == 1912){
				$wareki = "大正元年";
			}else{
				$year = $a - 1911;
				$wareki = "大正".$year."年";
			}

		}elseif($a <= 1988){//1926～1988)

			if($a == 1926){
				$wareki = "昭和元年";
			}else{
				$year = $a - 1925;
				$wareki = "昭和".$year."年";
			}

		}elseif($a <= 2018){//1989～2018)

			if($a == 1988){
				$wareki = "平成元年";
			}else{
				$year = $a - 1988;
				$wareki = "平成".$year."年";
			}

    }else {//2019～

			if($a == 2019){
				$wareki = "令和元年";
			}else{
				$year = $a - 2018;
				$wareki = "令和".$year."年";
			}

		}
	}
	return $wareki;
}

function h($string)
{
	return htmlspecialchars($string,ENT_QUOTES);
}

<?php
require_once "util.inc.php";
require_once "db.inc.php";

$id = $_GET["id"];
// var_dump($id);
// $id = 5;

if ($id == "") {
    $idError = "お知らせが指定されていません";
    header("Location: index.php");
}

$pdo = db_init();
try {
   $stmt = $pdo->prepare("SELECT * FROM news
   WHERE id = (?)");
   $stmt->execute(array($id));
   $itemList = $stmt->fetchAll(PDO::FETCH_ASSOC);
   // header("Location: news_add_done.php");
   }
   catch (PDOException $e) {
   echo $e->getMessage();
   exit;
  }
var_dump($itemList);

if ($_SERVER["REQUEST_METHOD"] === "POST") {

   $isValidated = TRUE;
   // 入力値の取得
   $date = $_POST["posted"];
   $title = $_POST["title"];
   $message = $_POST["message"];


if ($_POST["save"] == "保存") {

   if ($date == "") {
   $date = date("Y-m-d");
   }
   elseif (!preg_match("/^\d{4}-\d{2}-\d{2}$/", $date)) {
   $titleError = "日付は「0000-00-00」の形式で入力してください";
   var_dump($date);
   $isValidated = FALSE;
   }
   // タイトルのバリデーション
   if ($title === "") {
   $titleError = "※タイトルを入力してください";
   $isValidated = FALSE;
   }

   // お知らせのバリデーション
   if ($message === "") {
   $messageError = "※お知らせ内容を入力して下さい";
   $isValidated = FALSE;
   }
   //画像アップロードのバリデーション
   if ($_FILES["image"]["error"] == UPLOAD_ERR_OK) {
   $name = $_FILES["image"]["name"];
   $name = mb_convert_encoding($name, "cp932", "utf8");
   $temp = $_FILES["image"]["tmp_name"];
   var_dump($name);
      if (move_uploaded_file($temp, "../images/press/" . $name)) {
      // $imegeError = "アップロードされたファイルはありません。";
      }
   } elseif($_FILES["userfile"]["error"] == UPLOAD_ERR_NO_FILE) {
     // 何もしない
    } else {
      $imageError = "※アップロードに失敗しました";
      $name = "";
    }
  }
elseif ($_POST["cancel"] == "キャンセル") {
    header("Location: index.php");
 }

if($isValidated == TURE) {

$pdo = db_init();
try {
   $stmt = $pdo->prepare("UPDATE news SET
   posted = (?),
   title = (?),
   message = (?),
   image = (?)
   WHERE id = (?)");
   $stmt->execute(array($posted, $title, $message, $name, $id));
   // $itemList = $stmt->fetchAll(PDO::FETCH_ASSOC);
   header("Location: news_edit_done.php");
   }
   catch (PDOException $e) {
   echo $e->getMessage();
   exit;
  }
} else {
 header("Location: index.php");
}
}

?>


<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title>お知らせの編集 | Crescent Shoes 管理</title>
<link rel="stylesheet" href="css/admin.css">
</head>
<body>
<header>
  <div class="inner">
    <span><a href="index.html">Crescent Shoes 管理</a></span>
    <div id="account">
      admin
      [ <a href="logout.html">ログアウト</a> ]
    </div>
  </div>
</header>
<div id="container">
  <main>
    <h1>お知らせの編集</h1>
    <p>情報を入力し、「保存」ボタンを押してください。</p>
    <form action="" method="post" enctype="multipart/form-data">
        <?php foreach($itemList as $item): ?>
    <table>
      <tr>
        <th class="fixed">日付(任意)</th>
        <td>
          <?php if (isset($dateError)): ?>
          <div class="error"><?php echo h($dateError); ?></div>
          <?php endif; ?>
          <input type="date" name="posted" value="<?php echo h($item["posted"]); ?>">
        </td>
      </tr>
      <tr>
        <th class="fixed">タイトル</th>
        <td>
          <?php if (isset($titleError)): ?>
          <div class="error"><?php echo h($titleError); ?></div>
        <?php endif; ?>
          <input type="text" name="title" size="80" value="<?php echo h($item["title"]); ?>">

        </td>
      </tr>
      <tr>
        <th class="fixed">お知らせの内容</th>
        <td>
          <?php if (isset($messageError)): ?>
          <div class="error"><?php echo h($messageError); ?></div>
        <?php endif; ?>
          <textarea name="message" cols="80" rows="5"><?php echo h($item["message"]); ?></textarea>
        </td>
      </tr>
      <tr>
        <th class="fixed">画像(任意)</th>
        <td>
           <?php if (isset($imageError)): ?>
           <div class="error"><?php echo h($imageError); ?></div>
         <?php endif; ?>
          <input type="file" name="pic" value="../images/press/<?php echo h($item["image"]); ?>">
          <div><img src="../images/press/<?php echo h($item["image"]); ?>" width="64" height="64" alt=""></div>
        </td>
      </tr>
    </table>
 <?php endforeach; ?>
    <p>
      <input type="submit" name="save" value="保存">
      <input type="submit" name="cancel" value="キャンセル">
    </p>
    </form>
  </main>
  <footer>
    <p>&copy; Crescent Shoes All rights reserved.</p>
  </footer>
</div>
</body>
</html>

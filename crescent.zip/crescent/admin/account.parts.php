<div id="account">
    <?php echo h($_SESSION["admin_id"]); ?>
    [ <a href="logout.php">ログアウト</a> ]
</div>
